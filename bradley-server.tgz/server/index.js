import bcrypt from 'bcryptjs';
import cors from 'cors';
import express from 'express';
import jwt from 'jsonwebtoken';
import { networkInterfaces } from 'os';
import { v4 as uuid } from 'uuid';
import { getCleanerReminders, getOpenAiApiKey } from './ai/reminders.js';
import db from './db.js';
import {
  applyEstimateSuggestion,
  formatEstimateSuggestion,
  inferActualMinutesForVisit,
  listPendingEstimateSuggestions,
  processVisitCompletion,
  refreshAiSummariesForHome,
} from './services/estimateLearningService.js';
import { registerCleanerProfileRoutes } from './routes/cleanerProfile.js';
import { registerMarketplaceRoutes } from './routes/marketplace.js';
import { registerStripeWebhookRoutes } from './routes/stripeWebhooks.js';
import { resetStripeClient } from './lib/stripeClient.js';
import {
  getStripePublishableKey,
  isStripeConfigured,
  isStripeWebhookConfigured,
} from './lib/stripeConfig.js';
import {
  buildInvoiceFeeBreakdown,
  createCheckoutSessionForInvoice,
  createPaymentIntentForInvoice,
  fetchInvoiceById,
  formatInvoiceRow,
  invoiceHasSucceededPayment,
  markInvoicePaidFromPayment,
} from './services/invoiceService.js';
import { getCleanerConnectStatus } from './services/stripeConnectService.js';
import {
  completeTask,
  getVisitTaskContext,
  skipTask,
  startTask,
  updateVisitTaskStatus,
} from './services/taskTimingService.js';
import { ServiceError } from './lib/serviceError.js';

const app = express();
const PORT = Number(process.env.PORT || 3847);
const JWT_SECRET = process.env.JWT_SECRET || 'bradley-dev-secret-change-in-production';
const EXPO_PUSH_URL = 'https://exp.host/--/api/v2/push/send';
const DEFAULT_ADMIN_EMAILS = 'brandenthomas@gmail.com,branden.thomas@toweringmedia.com';
const SENSITIVE_SETTING_KEYS = new Set([
  'openai_api_key',
  'stripe_publishable_key',
  'stripe_secret_key',
  'stripe_webhook_secret',
]);
const ENV_ONLY_SETTING_KEYS = new Set(['STRIPE_SECRET_KEY', 'STRIPE_WEBHOOK_SECRET']);

const DECLINE_REASONS = {
  schedule_conflict: 'Schedule conflict',
  rate_too_low: 'Rate too low',
  too_far: 'Too far away',
  not_good_fit: 'Not a good fit',
  other: 'Other',
};

function formatDeclineReason(visit) {
  if (!visit?.decline_reason) return null;
  const label = DECLINE_REASONS[visit.decline_reason] || visit.decline_reason;
  if (visit.decline_reason === 'other' && visit.decline_reason_text?.trim()) {
    return `${label}: ${visit.decline_reason_text.trim()}`;
  }
  return label;
}

function normalizeTaskPriority(priority) {
  if (['must', 'nice', 'skip_visit'].includes(priority)) return priority;
  return null;
}

function parseAdminEmails() {
  return (process.env.ADMIN_EMAILS || DEFAULT_ADMIN_EMAILS)
    .split(',')
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
}

function isAdminUser(jwtUser) {
  if (!jwtUser?.id) return false;
  const row = db.prepare('SELECT email, role FROM users WHERE id = ?').get(jwtUser.id);
  if (!row) return false;
  if (row.role === 'admin') return true;
  return parseAdminEmails().includes(row.email.toLowerCase());
}

function requireAdmin(req, res, next) {
  if (!isAdminUser(req.user)) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

function maskSettingValue(key, value) {
  if (!value) return value ?? '';
  if (SENSITIVE_SETTING_KEYS.has(key) || key.includes('api_key') || key.includes('secret')) {
    return value.length > 4 ? `***${value.slice(-4)}` : '***';
  }
  return value;
}

function getSetting(key) {
  const row = db.prepare('SELECT value FROM app_settings WHERE key = ?').get(key);
  return row?.value ?? '';
}

function setSetting(key, value) {
  db.prepare(
    `INSERT INTO app_settings (key, value, updated_at) VALUES (?, ?, datetime('now'))
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')`
  ).run(key, value ?? '');
}

app.use(cors());
registerStripeWebhookRoutes(app);
app.use(express.json({ limit: '2mb' }));

function auth(req, res, next) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  try {
    req.user = jwt.verify(header.slice(7), JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

const TRIAL_DAYS = 14;
const DEV_SUBSCRIPTION =
  process.env.NODE_ENV !== 'production' || process.env.BRADLEY_DEV_SUBSCRIPTION === '1';

function getTrialEndsAt(user) {
  if (user.subscription_trial_ends_at) return user.subscription_trial_ends_at;
  if (user.created_at) {
    return db
      .prepare(`SELECT datetime(?, '+${TRIAL_DAYS} days') as ends`)
      .get(user.created_at)?.ends;
  }
  return null;
}

function resolveSubscriptionAccess(userRow, options = {}) {
  const { skipCleanerBypass = false } = options;
  if (!userRow) return { hasAccess: false, reason: 'not_found' };
  if (isAdminUser({ id: userRow.id })) {
    return { hasAccess: true, reason: 'admin', effectiveStatus: 'active' };
  }

  if (!skipCleanerBypass && userRow.role === 'cleaner') {
    const owners = db
      .prepare(
        `SELECT u.id, u.email, u.role, u.subscription_status, u.subscription_trial_ends_at,
                u.subscription_expires_at, u.created_at
         FROM homes h
         JOIN home_members hm ON hm.home_id = h.id AND hm.user_id = ? AND hm.role = 'cleaner'
         JOIN users u ON u.id = h.owner_id`
      )
      .all(userRow.id);

    for (const owner of owners) {
      const ownerAccess = resolveSubscriptionAccess(owner, { skipCleanerBypass: true });
      if (ownerAccess.hasAccess) {
        return {
          hasAccess: true,
          reason: 'cleaner_invited_by_paying_owner',
          effectiveStatus: 'active',
          trialEndsAt: ownerAccess.trialEndsAt,
          subscriptionExpiresAt: ownerAccess.subscriptionExpiresAt,
        };
      }
    }
  }

  const now = new Date();
  const trialEndsAt = getTrialEndsAt(userRow);

  if (userRow.subscription_status === 'active') {
    if (userRow.subscription_expires_at) {
      const expires = new Date(userRow.subscription_expires_at);
      if (expires <= now) {
        db.prepare(`UPDATE users SET subscription_status = 'expired' WHERE id = ?`).run(userRow.id);
        return { hasAccess: false, reason: 'expired', effectiveStatus: 'expired', trialEndsAt };
      }
    }
    return {
      hasAccess: true,
      reason: 'active',
      effectiveStatus: 'active',
      trialEndsAt,
      subscriptionExpiresAt: userRow.subscription_expires_at,
    };
  }

  if (userRow.subscription_status === 'trial') {
    if (trialEndsAt && new Date(trialEndsAt) > now) {
      return { hasAccess: true, reason: 'trial', effectiveStatus: 'trial', trialEndsAt };
    }
    db.prepare(`UPDATE users SET subscription_status = 'expired' WHERE id = ?`).run(userRow.id);
    return { hasAccess: false, reason: 'trial_expired', effectiveStatus: 'expired', trialEndsAt };
  }

  return {
    hasAccess: false,
    reason: userRow.subscription_status || 'expired',
    effectiveStatus: userRow.subscription_status || 'expired',
    trialEndsAt,
  };
}

function formatUserSubscription(userRow) {
  const access = resolveSubscriptionAccess(userRow);
  return {
    subscriptionStatus: access.effectiveStatus || userRow.subscription_status,
    trialEndsAt: access.trialEndsAt ?? getTrialEndsAt(userRow),
    subscriptionExpiresAt: userRow.subscription_expires_at ?? null,
    hasSubscriptionAccess: access.hasAccess,
  };
}

function requireSubscription(req, res, next) {
  const user = db
    .prepare(
      `SELECT id, email, role, subscription_status, subscription_trial_ends_at,
              subscription_expires_at, created_at
       FROM users WHERE id = ?`
    )
    .get(req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  const access = resolveSubscriptionAccess(user);
  if (!access.hasAccess) {
    return res.status(402).json({
      error: 'Subscription required',
      subscriptionStatus: access.effectiveStatus,
      trialEndsAt: access.trialEndsAt ?? null,
    });
  }
  next();
}

function authRequired(req, res, next) {
  auth(req, res, () => {
    if (res.headersSent) return;
    requireSubscription(req, res, next);
  });
}

async function sendExpoPush(tokens, { title, body, data }) {
  const unique = [...new Set(tokens.filter(Boolean))];
  if (!unique.length) return;

  const messages = unique.map((to) => ({
    to,
    sound: 'default',
    title,
    body,
    data: data || {},
    priority: 'high',
    channelId: 'bradley-alerts',
  }));

  try {
    await fetch(EXPO_PUSH_URL, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(messages),
    });
  } catch (err) {
    console.error('Push failed:', err.message);
  }
}

function cadenceDays(cadence) {
  if (cadence === 'weekly') return 7;
  if (cadence === 'monthly') return 30;
  return 90;
}

function isTaskDue(template, asOf = new Date()) {
  if (!template.active) return false;
  if (!template.last_completed_at) return true;
  const last = new Date(template.last_completed_at);
  const days = cadenceDays(template.cadence);
  const diff = (asOf.getTime() - last.getTime()) / (1000 * 60 * 60 * 24);
  return diff >= days;
}

function getHomeForUser(userId) {
  const owned = db.prepare('SELECT * FROM homes WHERE owner_id = ?').get(userId);
  if (owned) return owned;
  const member = db
    .prepare(
      `SELECT h.* FROM homes h
       JOIN home_members hm ON hm.home_id = h.id
       WHERE hm.user_id = ? AND hm.role IN ('member', 'cleaner')
       LIMIT 1`
    )
    .get(userId);
  return member || null;
}

function getUserHomeRole(userId, homeId) {
  const home = db.prepare('SELECT * FROM homes WHERE id = ?').get(homeId);
  if (!home) return null;
  if (home.owner_id === userId) return 'owner';
  const row = db
    .prepare('SELECT role FROM home_members WHERE home_id = ? AND user_id = ?')
    .get(homeId, userId);
  return row?.role || null;
}

function canManageHome(userId, homeId) {
  const role = getUserHomeRole(userId, homeId);
  return role === 'owner' || role === 'member';
}

function isHouseholdClient(userId, homeId) {
  const role = getUserHomeRole(userId, homeId);
  return role === 'owner' || role === 'member';
}

function userHasHome(userId) {
  return !!getHomeForUser(userId);
}

function getHouseholdManagers(homeId) {
  const home = db.prepare('SELECT * FROM homes WHERE id = ?').get(homeId);
  if (!home) return [];
  const members = db
    .prepare(
      `SELECT u.id, u.display_name, u.email, hm.role
       FROM users u
       JOIN home_members hm ON hm.user_id = u.id
       WHERE hm.home_id = ? AND hm.role IN ('owner', 'member')
       ORDER BY CASE hm.role WHEN 'owner' THEN 0 ELSE 1 END, u.display_name`
    )
    .all(homeId);
  if (!members.some((m) => m.id === home.owner_id)) {
    const owner = db
      .prepare('SELECT id, display_name, email FROM users WHERE id = ?')
      .get(home.owner_id);
    if (owner) members.unshift({ ...owner, role: 'owner' });
  }
  return members;
}

function getHouseholdManagerPushTokens(homeId, excludeUserId) {
  const managers = getHouseholdManagers(homeId);
  return managers
    .filter((m) => m.id !== excludeUserId)
    .map((m) => db.prepare('SELECT push_token FROM users WHERE id = ?').get(m.id)?.push_token)
    .filter(Boolean);
}

function getOwnerId(homeId) {
  const home = db.prepare('SELECT owner_id FROM homes WHERE id = ?').get(homeId);
  return home?.owner_id;
}

function getHomeMembers(homeId) {
  const home = db.prepare('SELECT * FROM homes WHERE id = ?').get(homeId);
  if (!home) return null;
  const cleaners = db
    .prepare(
      `SELECT u.* FROM users u
       JOIN home_members hm ON hm.user_id = u.id
       WHERE hm.home_id = ? AND hm.role = 'cleaner'`
    )
    .all(homeId);
  const owner = db.prepare('SELECT * FROM users WHERE id = ?').get(home.owner_id);
  return { home, owner, cleaners };
}

function buildVisitTasks(homeId, visitDate) {
  const templates = db
    .prepare(
      `SELECT tt.*, r.name as room_name FROM task_templates tt
       JOIN rooms r ON r.id = tt.room_id
       WHERE r.home_id = ? AND tt.active = 1`
    )
    .all(homeId);

  const asOf = new Date(visitDate);
  return templates.filter((t) => isTaskDue(t, asOf));
}

function ensureVisit(homeId, scheduledDate) {
  let visit = db
    .prepare('SELECT * FROM visits WHERE home_id = ? AND scheduled_date = ?')
    .get(homeId, scheduledDate);

  if (!visit) {
    const id = uuid();
    db.prepare(
      `INSERT INTO visits (id, home_id, scheduled_date, status, cleaner_response)
       VALUES (?, ?, ?, ?, 'pending')`
    ).run(id, homeId, scheduledDate, 'scheduled');
    visit = db.prepare('SELECT * FROM visits WHERE id = ?').get(id);

    const due = buildVisitTasks(homeId, scheduledDate);
    const insert = db.prepare(
      `INSERT INTO visit_tasks (id, visit_id, task_template_id, room_name, title, instructions, cadence, priority, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')`
    );
    for (const t of due) {
      insert.run(
        uuid(),
        visit.id,
        t.id,
        t.room_name,
        t.title,
        t.instructions,
        t.cadence,
        t.priority || 'must'
      );
    }
  }

  return visit;
}

function syncTemplateToUpcomingVisit(homeId, template, roomName) {
  const home = db.prepare('SELECT * FROM homes WHERE id = ?').get(homeId);
  if (!home) return;

  const date = nextVisitDate(home);
  const visit = db
    .prepare('SELECT * FROM visits WHERE home_id = ? AND scheduled_date = ?')
    .get(homeId, date);
  if (!visit || visit.status === 'completed') return;
  if (!isTaskDue(template, new Date(date))) return;

  const existing = db
    .prepare('SELECT id FROM visit_tasks WHERE visit_id = ? AND task_template_id = ?')
    .get(visit.id, template.id);
  if (existing) return;

  db.prepare(
    `INSERT INTO visit_tasks (id, visit_id, task_template_id, room_name, title, instructions, cadence, priority, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')`
  ).run(
    uuid(),
    visit.id,
    template.id,
    roomName,
    template.title,
    template.instructions,
    template.cadence,
    template.priority || 'must'
  );
}

function nextVisitDate(home) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const targetDow = home.visit_day;
  const d = new Date(today);
  const current = d.getDay();
  let delta = targetDow - current;
  if (delta < 0) delta += 7;
  if (delta === 0) return d.toISOString().slice(0, 10);
  d.setDate(d.getDate() + delta);
  return d.toISOString().slice(0, 10);
}

function computeVisitEstimates(visitId, hourlyRateCents) {
  const row = db
    .prepare(
      `SELECT COALESCE(SUM(COALESCE(tt.estimated_minutes, 15)), 0) as total
       FROM visit_tasks vt
       LEFT JOIN task_templates tt ON tt.id = vt.task_template_id
       WHERE vt.visit_id = ?`
    )
    .get(visitId);
  const totalEstimatedMinutes = row.total;
  const rate = hourlyRateCents ?? null;
  const estimatedCostCents =
    rate != null ? Math.round((totalEstimatedMinutes * rate) / 60) : null;
  return { totalEstimatedMinutes, estimatedCostCents, hourlyRateCents: rate };
}

function enrichVisitTask(task) {
  const estimated = task.task_template_id
    ? db.prepare('SELECT estimated_minutes FROM task_templates WHERE id = ?').get(task.task_template_id)
    : null;
  return {
    ...task,
    estimated_minutes: estimated?.estimated_minutes ?? 15,
  };
}

function handleServiceError(err, res) {
  if (err instanceof ServiceError) {
    return res.status(err.status).json({ error: err.message });
  }
  console.error('[api]', err);
  return res.status(500).json({ error: 'Something went wrong' });
}

function assertVisitHouseholdMember(userId, homeId) {
  if (!getUserHomeRole(userId, homeId)) {
    throw new ServiceError('Not a member of this visit\'s household', { status: 403 });
  }
}

function loadVisitTaskForRoute(visitId, taskId) {
  const visit = db.prepare('SELECT * FROM visits WHERE id = ?').get(visitId);
  if (!visit) throw new ServiceError('Visit not found', { status: 404 });

  const vt = getVisitTaskContext(taskId);
  if (!vt) throw new ServiceError('Task not found', { status: 404 });
  if (vt.visit_id !== visitId) {
    throw new ServiceError('Task does not belong to this visit', { status: 400 });
  }

  return { visit, vt };
}

function buildVisitSummary(visitId, homeId, userId, userRole) {
  const home = db.prepare('SELECT hourly_rate_cents FROM homes WHERE id = ?').get(homeId);
  const estimates = computeVisitEstimates(visitId, home?.hourly_rate_cents);
  const tasks = db
    .prepare('SELECT * FROM visit_tasks WHERE visit_id = ? ORDER BY room_name, title')
    .all(visitId);
  const questionsCount = db
    .prepare(
      `SELECT COUNT(*) as c FROM task_questions q
       JOIN visit_tasks vt ON vt.id = q.visit_task_id
       WHERE vt.visit_id = ?`
    )
    .get(visitId).c;

  const done = tasks.filter((t) => t.status === 'done');
  const skipped = tasks.filter((t) => t.status === 'skipped');
  const pending = tasks.filter((t) => t.status === 'pending');
  const inProgress = tasks.filter((t) => t.status === 'in_progress');
  const blocked = tasks.filter((t) => t.status === 'blocked');

  const feedbackRow = db
    .prepare('SELECT id FROM visit_feedback WHERE visit_id = ? LIMIT 1')
    .get(visitId);

  let invoiceRow = null;
  if (userRole === 'cleaner') {
    invoiceRow = db
      .prepare(
        `SELECT id, status FROM invoices
         WHERE visit_id = ? AND cleaner_id = ?
         ORDER BY created_at DESC LIMIT 1`
      )
      .get(visitId, userId);
  } else {
    invoiceRow = db
      .prepare(`SELECT id, status FROM invoices WHERE visit_id = ? ORDER BY created_at DESC LIMIT 1`)
      .get(visitId);
  }

  return {
    done: done.length,
    skipped: skipped.length,
    pending: pending.length,
    inProgress: inProgress.length,
    blocked: blocked.length,
    total: tasks.length,
    questionsCount,
    totalEstimatedMinutes: estimates.totalEstimatedMinutes,
    estimatedCostCents: estimates.estimatedCostCents,
    tasksCompleted: done.map((t) => ({
      id: t.id,
      title: t.title,
      room_name: t.room_name,
      priority: t.priority || 'must',
    })),
    tasksSkipped: skipped.map((t) => ({
      id: t.id,
      title: t.title,
      room_name: t.room_name,
      skip_reason: t.skip_reason,
      priority: t.priority || 'must',
    })),
    feedbackSubmitted: !!feedbackRow,
    invoice: invoiceRow ? { id: invoiceRow.id, status: invoiceRow.status } : null,
    estimateSuggestions: listPendingEstimateSuggestions(homeId),
  };
}

// ─── Auth ───────────────────────────────────────────────────────────────────

app.post('/auth/register', (req, res) => {
  const { email, password, displayName, role } = req.body;
  if (!email || !password || !displayName || !['client', 'cleaner'].includes(role)) {
    return res.status(400).json({ error: 'Invalid registration data' });
  }
  if (role === 'admin') {
    return res.status(400).json({ error: 'Invalid registration data' });
  }
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase());
  if (existing) return res.status(409).json({ error: 'Email already registered' });

  const id = uuid();
  const hash = bcrypt.hashSync(password, 10);
  db.prepare(
    `INSERT INTO users (id, email, password_hash, display_name, role, subscription_status, subscription_trial_ends_at)
     VALUES (?, ?, ?, ?, ?, 'trial', datetime('now', '+${TRIAL_DAYS} days'))`
  ).run(id, email.toLowerCase(), hash, displayName, role);

  const userRow = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  const token = jwt.sign({ id, email: email.toLowerCase(), role }, JWT_SECRET, { expiresIn: '30d' });
  res.json({
    token,
    user: {
      id,
      email: email.toLowerCase(),
      displayName,
      role,
      isAdmin: isAdminUser({ id }),
      ...formatUserSubscription(userRow),
    },
  });
});

app.post('/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email?.toLowerCase());
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  const token = jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    JWT_SECRET,
    { expiresIn: '30d' }
  );
  res.json({
    token,
    user: {
      id: user.id,
      email: user.email,
      displayName: user.display_name,
      role: user.role,
      isAdmin: isAdminUser({ id: user.id }),
      ...formatUserSubscription(user),
    },
  });
});

app.get('/auth/me', auth, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({
    id: user.id,
    email: user.email,
    displayName: user.display_name,
    role: user.role,
    pushToken: user.push_token,
    isAdmin: isAdminUser(req.user),
    ...formatUserSubscription(user),
  });
});

app.put('/auth/push-token', auth, (req, res) => {
  const { pushToken } = req.body;
  db.prepare('UPDATE users SET push_token = ? WHERE id = ?').run(pushToken || null, req.user.id);
  res.json({ ok: true });
});

// ─── Subscription ───────────────────────────────────────────────────────────

app.post('/subscription/activate-dev', auth, (req, res) => {
  if (!DEV_SUBSCRIPTION) {
    return res.status(403).json({ error: 'Play Store billing coming soon' });
  }
  const expiresAt = db
    .prepare(`SELECT datetime('now', '+1 year') as expires`)
    .get().expires;
  db.prepare(
    `UPDATE users SET subscription_status = 'active', subscription_expires_at = ? WHERE id = ?`
  ).run(expiresAt, req.user.id);
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  res.json({ ok: true, ...formatUserSubscription(user) });
});

// ─── Homes ──────────────────────────────────────────────────────────────────

app.post('/homes', authRequired, (req, res) => {
  if (req.user.role !== 'client') {
    return res.status(403).json({ error: 'Only clients can create homes' });
  }
  if (userHasHome(req.user.id)) {
    return res.status(409).json({ error: 'You are already in a household' });
  }

  const { name, visitDay, visitTime } = req.body;
  const id = uuid();
  db.prepare(
    'INSERT INTO homes (id, owner_id, name, visit_day, visit_time) VALUES (?, ?, ?, ?, ?)'
  ).run(id, req.user.id, name || 'My Home', visitDay ?? 2, visitTime || '10:00');

  db.prepare('INSERT INTO home_members (home_id, user_id, role) VALUES (?, ?, ?)').run(
    id,
    req.user.id,
    'owner'
  );

  const defaultRooms = [
    { name: 'Kitchen', tasks: [
      { title: 'Wipe counters', cadence: 'weekly', instructions: 'Use granite-safe cleaner under sink.' },
      { title: 'Clean appliances', cadence: 'monthly', instructions: 'Wipe microwave inside and out.' },
    ]},
    { name: 'Bathrooms', tasks: [
      { title: 'Clean toilets', cadence: 'weekly', instructions: '' },
      { title: 'Scrub shower', cadence: 'monthly', instructions: 'Use non-abrasive scrub.' },
    ]},
    { name: 'Living Areas', tasks: [
      { title: 'Vacuum floors', cadence: 'weekly', instructions: 'Include under couch cushions.' },
      { title: 'Dust surfaces', cadence: 'monthly', instructions: '' },
    ]},
    { name: 'Bedrooms', tasks: [
      { title: 'Change linens', cadence: 'weekly', instructions: 'Fresh sheets in hall closet.' },
      { title: 'Deep clean closets', cadence: 'quarterly', instructions: '' },
    ]},
  ];

  const roomInsert = db.prepare('INSERT INTO rooms (id, home_id, name, sort_order) VALUES (?, ?, ?, ?)');
  const taskInsert = db.prepare(
    'INSERT INTO task_templates (id, room_id, title, instructions, cadence) VALUES (?, ?, ?, ?, ?)'
  );

  defaultRooms.forEach((room, i) => {
    const roomId = uuid();
    roomInsert.run(roomId, id, room.name, i);
    room.tasks.forEach((t) => taskInsert.run(uuid(), roomId, t.title, t.instructions, t.cadence));
  });

  const home = db.prepare('SELECT * FROM homes WHERE id = ?').get(id);
  res.json(home);
});

app.get('/homes/mine', authRequired, (req, res) => {
  const home = getHomeForUser(req.user.id);
  if (!home) return res.json(null);
  const rooms = db
    .prepare('SELECT * FROM rooms WHERE home_id = ? ORDER BY sort_order')
    .all(home.id);
  const tasks = db
    .prepare(
      `SELECT tt.*, r.name as room_name FROM task_templates tt
       JOIN rooms r ON r.id = tt.room_id
       WHERE r.home_id = ? ORDER BY r.sort_order, tt.title`
    )
    .all(home.id);
  const householdMembers = getHouseholdManagers(home.id);
  const myHomeRole = getUserHomeRole(req.user.id, home.id);
  res.json({ ...home, rooms, tasks, householdMembers, myHomeRole });
});

app.get('/homes/:id/household', authRequired, (req, res) => {
  const home = db.prepare('SELECT * FROM homes WHERE id = ?').get(req.params.id);
  if (!home || !canManageHome(req.user.id, home.id)) {
    return res.status(403).json({ error: 'Not allowed' });
  }
  res.json({ members: getHouseholdManagers(home.id) });
});

app.patch('/homes/:id', authRequired, (req, res) => {
  const home = db.prepare('SELECT * FROM homes WHERE id = ?').get(req.params.id);
  if (!home || !canManageHome(req.user.id, home.id)) {
    return res.status(403).json({ error: 'Not allowed' });
  }
  const { name, visitDay, visitTime, hourlyRateCents } = req.body;
  if (hourlyRateCents !== undefined && hourlyRateCents !== null) {
    if (!Number.isInteger(hourlyRateCents) || hourlyRateCents < 0) {
      return res.status(400).json({ error: 'Invalid hourly rate' });
    }
  }
  db.prepare(
    `UPDATE homes SET
      name = COALESCE(?, name),
      visit_day = COALESCE(?, visit_day),
      visit_time = COALESCE(?, visit_time),
      hourly_rate_cents = CASE WHEN ? THEN ? ELSE hourly_rate_cents END
     WHERE id = ?`
  ).run(
    name ?? null,
    visitDay ?? null,
    visitTime ?? null,
    hourlyRateCents !== undefined ? 1 : 0,
    hourlyRateCents ?? null,
    home.id
  );
  res.json(db.prepare('SELECT * FROM homes WHERE id = ?').get(home.id));
});

// ─── Invites ────────────────────────────────────────────────────────────────

app.post('/homes/:id/invite', authRequired, (req, res) => {
  const home = db.prepare('SELECT * FROM homes WHERE id = ?').get(req.params.id);
  if (!home || !canManageHome(req.user.id, home.id)) {
    return res.status(403).json({ error: 'Not allowed' });
  }
  const inviteRole = req.body.inviteRole === 'member' ? 'member' : 'cleaner';
  const code = uuid().slice(0, 8).toUpperCase();
  const expires = new Date();
  expires.setDate(expires.getDate() + 7);
  db.prepare('INSERT INTO invites (code, home_id, role, expires_at) VALUES (?, ?, ?, ?)').run(
    code,
    home.id,
    inviteRole,
    expires.toISOString()
  );
  res.json({ code, expiresAt: expires.toISOString(), inviteRole });
});

app.post('/invites/join', authRequired, (req, res) => {
  const { code } = req.body;
  const invite = db.prepare('SELECT * FROM invites WHERE code = ?').get(code?.toUpperCase());
  if (!invite) return res.status(404).json({ error: 'Invalid invite code' });
  if (invite.used_by) return res.status(409).json({ error: 'Invite already used' });
  if (new Date(invite.expires_at) < new Date()) {
    return res.status(410).json({ error: 'Invite expired' });
  }

  const memberRole = invite.role === 'member' ? 'member' : 'cleaner';
  if (memberRole === 'member' && req.user.role !== 'client') {
    return res.status(403).json({ error: 'Household invites are for homeowners and renters' });
  }
  if (memberRole === 'cleaner' && req.user.role !== 'cleaner') {
    return res.status(403).json({ error: 'Cleaner invites are for cleaners' });
  }
  if (userHasHome(req.user.id)) {
    return res.status(409).json({ error: 'You are already in a household' });
  }

  db.prepare('INSERT OR IGNORE INTO home_members (home_id, user_id, role) VALUES (?, ?, ?)').run(
    invite.home_id,
    req.user.id,
    memberRole
  );
  db.prepare('UPDATE invites SET used_by = ? WHERE code = ?').run(req.user.id, invite.code);

  const home = db.prepare('SELECT * FROM homes WHERE id = ?').get(invite.home_id);
  res.json({ ...home, myHomeRole: memberRole });
});

// ─── Rooms & Tasks ──────────────────────────────────────────────────────────

app.post('/homes/:homeId/rooms', authRequired, (req, res) => {
  const home = db.prepare('SELECT * FROM homes WHERE id = ?').get(req.params.homeId);
  if (!home || !canManageHome(req.user.id, home.id)) {
    return res.status(403).json({ error: 'Not allowed' });
  }
  const { name } = req.body;
  const maxOrder = db
    .prepare('SELECT COALESCE(MAX(sort_order), -1) as m FROM rooms WHERE home_id = ?')
    .get(home.id).m;
  const id = uuid();
  db.prepare('INSERT INTO rooms (id, home_id, name, sort_order) VALUES (?, ?, ?, ?)').run(
    id,
    home.id,
    name,
    maxOrder + 1
  );
  res.json(db.prepare('SELECT * FROM rooms WHERE id = ?').get(id));
});

app.post('/rooms/:roomId/tasks', authRequired, (req, res) => {
  const room = db
    .prepare(`SELECT r.*, r.home_id FROM rooms r WHERE r.id = ?`)
    .get(req.params.roomId);
  if (!room || !canManageHome(req.user.id, room.home_id)) {
    return res.status(403).json({ error: 'Not allowed' });
  }
  const { title, instructions, cadence, estimatedMinutes, priority } = req.body;
  if (!title || !['weekly', 'monthly', 'quarterly'].includes(cadence)) {
    return res.status(400).json({ error: 'Invalid task data' });
  }
  const minutes = estimatedMinutes ?? 15;
  if (!Number.isInteger(minutes) || minutes < 1) {
    return res.status(400).json({ error: 'Invalid estimated minutes' });
  }
  const taskPriority = priority !== undefined ? normalizeTaskPriority(priority) : 'must';
  if (priority !== undefined && !taskPriority) {
    return res.status(400).json({ error: 'Invalid task priority' });
  }
  const id = uuid();
  db.prepare(
    'INSERT INTO task_templates (id, room_id, title, instructions, cadence, estimated_minutes, priority) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).run(id, room.id, title, instructions || '', cadence, minutes, taskPriority);
  const template = db.prepare('SELECT * FROM task_templates WHERE id = ?').get(id);
  syncTemplateToUpcomingVisit(room.home_id, template, room.name);
  res.json(template);
});

app.patch('/tasks/:id', authRequired, (req, res) => {
  const task = db
    .prepare(
      `SELECT tt.*, r.home_id FROM task_templates tt
       JOIN rooms r ON r.id = tt.room_id
       WHERE tt.id = ?`
    )
    .get(req.params.id);
  if (!task || !canManageHome(req.user.id, task.home_id)) {
    return res.status(403).json({ error: 'Not allowed' });
  }
  const { title, instructions, cadence, active, estimatedMinutes, priority } = req.body;
  if (estimatedMinutes !== undefined && estimatedMinutes !== null) {
    if (!Number.isInteger(estimatedMinutes) || estimatedMinutes < 1) {
      return res.status(400).json({ error: 'Invalid estimated minutes' });
    }
  }
  if (priority !== undefined && priority !== null && !normalizeTaskPriority(priority)) {
    return res.status(400).json({ error: 'Invalid task priority' });
  }
  db.prepare(
    `UPDATE task_templates SET
      title = COALESCE(?, title),
      instructions = COALESCE(?, instructions),
      cadence = COALESCE(?, cadence),
      active = COALESCE(?, active),
      estimated_minutes = COALESCE(?, estimated_minutes),
      priority = COALESCE(?, priority)
     WHERE id = ?`
  ).run(
    title ?? null,
    instructions ?? null,
    cadence ?? null,
    active === undefined ? null : active ? 1 : 0,
    estimatedMinutes ?? null,
    priority ?? null,
    task.id
  );
  res.json(db.prepare('SELECT * FROM task_templates WHERE id = ?').get(task.id));
});

// ─── Estimate learning suggestions ───────────────────────────────────────────

app.get('/homes/:homeId/estimate-suggestions', authRequired, (req, res) => {
  const home = db.prepare('SELECT id FROM homes WHERE id = ?').get(req.params.homeId);
  if (!home) return res.status(404).json({ error: 'Not found' });
  if (!getUserHomeRole(req.user.id, home.id) && !isAdminUser(req.user)) {
    return res.status(403).json({ error: 'Not allowed' });
  }
  res.json(listPendingEstimateSuggestions(home.id));
});

app.post('/estimate-suggestions/:id/apply', authRequired, (req, res) => {
  const suggestion = db
    .prepare('SELECT * FROM task_estimate_suggestions WHERE id = ?')
    .get(req.params.id);
  if (!suggestion) return res.status(404).json({ error: 'Not found' });
  if (!canManageHome(req.user.id, suggestion.home_id) && !isAdminUser(req.user)) {
    return res.status(403).json({ error: 'Not allowed' });
  }

  const result = applyEstimateSuggestion(db, suggestion.id);
  if (result?.error) return res.status(400).json({ error: result.error });
  res.json(formatEstimateSuggestion(result));
});

app.post('/estimate-suggestions/:id/dismiss', authRequired, (req, res) => {
  const suggestion = db
    .prepare('SELECT * FROM task_estimate_suggestions WHERE id = ?')
    .get(req.params.id);
  if (!suggestion) return res.status(404).json({ error: 'Not found' });
  if (!canManageHome(req.user.id, suggestion.home_id) && !isAdminUser(req.user)) {
    return res.status(403).json({ error: 'Not allowed' });
  }

  db.prepare(
    `UPDATE task_estimate_suggestions SET status = 'dismissed' WHERE id = ?`
  ).run(suggestion.id);

  const row = db
    .prepare(
      `SELECT s.*, tt.title, r.name AS room_name, h.name AS home_name
       FROM task_estimate_suggestions s
       JOIN task_templates tt ON tt.id = s.task_template_id
       JOIN rooms r ON r.id = tt.room_id
       JOIN homes h ON h.id = s.home_id
       WHERE s.id = ?`
    )
    .get(suggestion.id);
  res.json(formatEstimateSuggestion(row));
});

app.get('/admin/estimate-suggestions', authRequired, requireAdmin, (_req, res) => {
  const rows = db
    .prepare(
      `SELECT s.*, tt.title, r.name AS room_name, h.name AS home_name
       FROM task_estimate_suggestions s
       JOIN task_templates tt ON tt.id = s.task_template_id
       JOIN rooms r ON r.id = tt.room_id
       JOIN homes h ON h.id = s.home_id
       WHERE s.status = 'pending'
       ORDER BY s.created_at DESC`
    )
    .all();
  res.json(rows.map(formatEstimateSuggestion));
});

// ─── Visits ─────────────────────────────────────────────────────────────────

app.get('/visits/upcoming', authRequired, async (req, res) => {
  const home = getHomeForUser(req.user.id);
  if (!home) return res.json(null);

  const date = nextVisitDate(home);
  const visit = ensureVisit(home.id, date);
  const tasks = db
    .prepare('SELECT * FROM visit_tasks WHERE visit_id = ? ORDER BY room_name, title')
    .all(visit.id);

  const tasksWithQuestions = tasks.map((t) => {
    const questions = db
      .prepare(
        `SELECT q.*, u.display_name as author_name, u.role as author_role
         FROM task_questions q JOIN users u ON u.id = q.author_id
         WHERE q.visit_task_id = ? ORDER BY q.created_at`
      )
      .all(t.id);
    return enrichVisitTask({ ...t, questions });
  });

  const payload = {
    visit: {
      ...visit,
      declineReasonLabel: formatDeclineReason(visit),
    },
    tasks: tasksWithQuestions,
    home,
    ...computeVisitEstimates(visit.id, home.hourly_rate_cents),
  };

  if (req.user.role === 'cleaner') {
    try {
      payload.cleanerReminders = await getCleanerReminders({
        db,
        homeId: home.id,
        visitId: visit.id,
        getSetting,
      });
    } catch (err) {
      console.error('[visits/upcoming] cleanerReminders failed:', err);
      payload.cleanerReminders = [];
    }
  }

  res.json(payload);
});

app.get('/visits/history', authRequired, (req, res) => {
  const home = getHomeForUser(req.user.id);
  if (!home) return res.json([]);
  const visits = db
    .prepare(
      `SELECT * FROM visits WHERE home_id = ? AND status = 'completed'
       ORDER BY scheduled_date DESC LIMIT 20`
    )
    .all(home.id);
  res.json(visits);
});

app.get('/visits/:id', authRequired, (req, res) => {
  const visit = db.prepare('SELECT * FROM visits WHERE id = ?').get(req.params.id);
  if (!visit) return res.status(404).json({ error: 'Not found' });
  const home = getHomeForUser(req.user.id);
  if (!home || home.id !== visit.home_id) {
    return res.status(403).json({ error: 'Not allowed' });
  }
  const tasks = db
    .prepare('SELECT * FROM visit_tasks WHERE visit_id = ? ORDER BY room_name, title')
    .all(visit.id);
  const tasksWithQuestions = tasks.map((t) => {
    const questions = db
      .prepare(
        `SELECT q.*, u.display_name as author_name, u.role as author_role
         FROM task_questions q JOIN users u ON u.id = q.author_id
         WHERE q.visit_task_id = ? ORDER BY q.created_at`
      )
      .all(t.id);
    return enrichVisitTask({ ...t, questions });
  });
  res.json({
    visit: {
      ...visit,
      declineReasonLabel: formatDeclineReason(visit),
    },
    tasks: tasksWithQuestions,
    ...computeVisitEstimates(visit.id, home.hourly_rate_cents),
  });
});

app.post('/visits/:id/respond', authRequired, (req, res) => {
  const visit = db.prepare('SELECT * FROM visits WHERE id = ?').get(req.params.id);
  if (!visit) return res.status(404).json({ error: 'Not found' });

  const homeRole = getUserHomeRole(req.user.id, visit.home_id);
  if (homeRole !== 'cleaner') {
    return res.status(403).json({ error: 'Only the assigned cleaner can respond to this visit' });
  }
  if (visit.status !== 'scheduled') {
    return res.status(400).json({ error: 'Visit is no longer scheduled' });
  }
  if (visit.cleaner_response !== 'pending') {
    return res.status(409).json({ error: 'You already responded to this visit' });
  }

  const { response, declineReason, declineReasonText } = req.body;
  if (!['accepted', 'declined'].includes(response)) {
    return res.status(400).json({ error: 'Response must be accepted or declined' });
  }

  if (response === 'declined') {
    if (!declineReason || !DECLINE_REASONS[declineReason]) {
      return res.status(400).json({ error: 'Decline reason required' });
    }
    if (declineReason === 'other' && !declineReasonText?.trim()) {
      return res.status(400).json({ error: 'Please describe your reason' });
    }
  }

  db.prepare(
    `UPDATE visits SET
      cleaner_response = ?,
      cleaner_responded_at = datetime('now'),
      decline_reason = ?,
      decline_reason_text = ?
     WHERE id = ?`
  ).run(
    response,
    response === 'declined' ? declineReason : null,
    response === 'declined' ? declineReasonText?.trim() || null : null,
    visit.id
  );

  const updated = db.prepare('SELECT * FROM visits WHERE id = ?').get(visit.id);
  const declineLabel = formatDeclineReason(updated);
  const home = db.prepare('SELECT name FROM homes WHERE id = ?').get(visit.home_id);
  const cleaner = db.prepare('SELECT display_name FROM users WHERE id = ?').get(req.user.id);
  const managerTokens = getHouseholdManagerPushTokens(visit.home_id, req.user.id);

  const accepted = response === 'accepted';
  void sendExpoPush(managerTokens, {
    title: accepted ? 'Cleaner accepted job' : 'Cleaner declined job',
    body: accepted
      ? `${cleaner?.display_name || 'Your cleaner'} accepted the ${visit.scheduled_date} visit at ${home?.name || 'your home'}.`
      : `${cleaner?.display_name || 'Your cleaner'} declined the ${visit.scheduled_date} visit${declineLabel ? ` (${declineLabel})` : ''}. You may need to find another cleaner or reschedule.`,
    data: { type: accepted ? 'visit_accepted' : 'visit_declined', visitId: visit.id },
  });

  res.json({
    ...updated,
    declineReasonLabel: declineLabel,
  });
});

app.post('/visits/:id/start', authRequired, (req, res) => {
  const visit = db.prepare('SELECT * FROM visits WHERE id = ?').get(req.params.id);
  if (!visit) return res.status(404).json({ error: 'Not found' });
  if (visit.status !== 'scheduled') {
    return res.json(db.prepare('SELECT * FROM visits WHERE id = ?').get(visit.id));
  }

  const homeRole = getUserHomeRole(req.user.id, visit.home_id);
  if (homeRole === 'cleaner' && visit.cleaner_response !== 'accepted') {
    return res.status(403).json({
      error:
        visit.cleaner_response === 'declined'
          ? 'You declined this visit'
          : 'Accept the job before starting the visit',
    });
  }

  db.prepare(
    `UPDATE visits SET status = 'in_progress', started_at = datetime('now') WHERE id = ?`
  ).run(visit.id);

  const ownerId = getOwnerId(visit.home_id);
  const owner = db.prepare('SELECT push_token, display_name FROM users WHERE id = ?').get(ownerId);
  const cleaner = db.prepare('SELECT display_name FROM users WHERE id = ?').get(req.user.id);
  void sendExpoPush([owner?.push_token], {
    title: 'Cleaning started',
    body: `${cleaner?.display_name || 'Your cleaner'} started today's visit.`,
    data: { type: 'visit_started', visitId: visit.id },
  });

  res.json(db.prepare('SELECT * FROM visits WHERE id = ?').get(visit.id));
});

app.post('/visits/:visitId/tasks/:taskId/start', authRequired, (req, res) => {
  try {
    const { visit } = loadVisitTaskForRoute(req.params.visitId, req.params.taskId);
    assertVisitHouseholdMember(req.user.id, visit.home_id);
    const updated = startTask(req.params.taskId, req.user.id);
    res.json(enrichVisitTask(updated));
  } catch (err) {
    return handleServiceError(err, res);
  }
});

app.post('/visits/:visitId/tasks/:taskId/complete', authRequired, (req, res) => {
  try {
    const { visit } = loadVisitTaskForRoute(req.params.visitId, req.params.taskId);
    assertVisitHouseholdMember(req.user.id, visit.home_id);
    const updated = completeTask(req.params.taskId, req.user.id);
    res.json(enrichVisitTask(updated));
  } catch (err) {
    return handleServiceError(err, res);
  }
});

app.post('/visit-tasks/:id/start', authRequired, (req, res) => {
  try {
    const updated = startTask(req.params.id, req.user.id);
    res.json(enrichVisitTask(updated));
  } catch (err) {
    return handleServiceError(err, res);
  }
});

app.post('/visit-tasks/:id/complete', authRequired, (req, res) => {
  try {
    const updated = completeTask(req.params.id, req.user.id);
    res.json(enrichVisitTask(updated));
  } catch (err) {
    return handleServiceError(err, res);
  }
});

app.patch('/visit-tasks/:id', authRequired, (req, res) => {
  try {
    const { status, skipReason } = req.body;
    const updated = updateVisitTaskStatus(req.params.id, {
      status,
      skipReason,
      userId: req.user.id,
      userRole: req.user.role,
    });
    res.json(enrichVisitTask(updated));
  } catch (err) {
    return handleServiceError(err, res);
  }
});

app.post('/visits/:id/complete', authRequired, async (req, res) => {
  const visit = db.prepare('SELECT * FROM visits WHERE id = ?').get(req.params.id);
  if (!visit) return res.status(404).json({ error: 'Not found' });

  db.prepare(
    `UPDATE visits SET status = 'completed', completed_at = datetime('now') WHERE id = ?`
  ).run(visit.id);

  inferActualMinutesForVisit(db, visit.id);

  try {
    processVisitCompletion(visit.id, visit.home_id, db);
    await refreshAiSummariesForHome(visit.home_id, getSetting, db);
  } catch (err) {
    console.error('[visits/complete] estimate learning failed:', err.message);
  }

  const tasks = db.prepare('SELECT status FROM visit_tasks WHERE visit_id = ?').all(visit.id);
  const done = tasks.filter((t) => t.status === 'done').length;
  const skipped = tasks.filter((t) => t.status === 'skipped').length;
  const pending = tasks.filter((t) => t.status === 'pending' || t.status === 'in_progress').length;

  const summary = buildVisitSummary(visit.id, visit.home_id, req.user.id, req.user.role);

  const ownerId = getOwnerId(visit.home_id);
  const owner = db.prepare('SELECT push_token FROM users WHERE id = ?').get(ownerId);
  void sendExpoPush([owner?.push_token], {
    title: 'Visit complete',
    body: `${done} done, ${skipped} skipped, ${pending} pending.`,
    data: { type: 'visit_completed', visitId: visit.id },
  });

  res.json({
    visit: db.prepare('SELECT * FROM visits WHERE id = ?').get(visit.id),
    summary,
  });
});

app.post('/visits/:id/feedback', authRequired, (req, res) => {
  const visit = db.prepare('SELECT * FROM visits WHERE id = ?').get(req.params.id);
  if (!visit) return res.status(404).json({ error: 'Not found' });
  if (visit.status !== 'completed') {
    return res.status(400).json({ error: 'Visit must be completed before feedback' });
  }
  if (!isHouseholdClient(req.user.id, visit.home_id)) {
    return res.status(403).json({ error: 'Only household clients can submit feedback' });
  }

  const wentWell = (req.body.wentWell ?? req.body.went_well ?? '').trim();
  const needsImprovement = (req.body.needsImprovement ?? req.body.needs_improvement ?? '').trim();
  if (!wentWell && !needsImprovement) {
    return res.status(400).json({ error: 'Enter at least one comment' });
  }

  const existing = db
    .prepare('SELECT id FROM visit_feedback WHERE visit_id = ? AND author_id = ?')
    .get(visit.id, req.user.id);
  if (existing) {
    return res.status(409).json({ error: 'You already submitted feedback for this visit' });
  }

  const id = uuid();
  db.prepare(
    `INSERT INTO visit_feedback (id, visit_id, home_id, author_id, went_well, needs_improvement)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(id, visit.id, visit.home_id, req.user.id, wentWell, needsImprovement);

  const cleaners = db
    .prepare(
      `SELECT u.push_token FROM users u
       JOIN home_members hm ON hm.user_id = u.id
       WHERE hm.home_id = ? AND hm.role = 'cleaner'`
    )
    .all(visit.home_id);
  const author = db.prepare('SELECT display_name FROM users WHERE id = ?').get(req.user.id);
  void sendExpoPush(
    cleaners.map((c) => c.push_token),
    {
      title: 'Visit feedback',
      body: `${author?.display_name || 'Client'} shared feedback on today's visit.`,
      data: { type: 'visit_feedback', visitId: visit.id, feedbackId: id },
    }
  );

  const row = db
    .prepare(
      `SELECT f.*, u.display_name as author_name, v.scheduled_date as visit_date
       FROM visit_feedback f
       JOIN users u ON u.id = f.author_id
       JOIN visits v ON v.id = f.visit_id
       WHERE f.id = ?`
    )
    .get(id);
  res.status(201).json(row);
});

app.get('/homes/:homeId/feedback', authRequired, (req, res) => {
  const role = getUserHomeRole(req.user.id, req.params.homeId);
  if (!role) return res.status(403).json({ error: 'Not a member of this home' });

  const feedback = db
    .prepare(
      `SELECT f.*, u.display_name as author_name, v.scheduled_date as visit_date
       FROM visit_feedback f
       JOIN users u ON u.id = f.author_id
       JOIN visits v ON v.id = f.visit_id
       WHERE f.home_id = ?
       ORDER BY f.created_at DESC
       LIMIT 50`
    )
    .all(req.params.homeId);

  if (role === 'cleaner') {
    return res.json({
      feedback: feedback.map((f) => ({
        id: f.id,
        visit_id: f.visit_id,
        home_id: f.home_id,
        author_id: f.author_id,
        went_well: f.went_well,
        needs_improvement: '',
        created_at: f.created_at,
        author_name: f.author_name,
        visit_date: f.visit_date,
      })),
    });
  }

  res.json({ feedback });
});

// ─── Questions ──────────────────────────────────────────────────────────────

app.post('/visit-tasks/:id/questions', authRequired, (req, res) => {
  const vt = db
    .prepare(
      `SELECT vt.*, v.home_id FROM visit_tasks vt JOIN visits v ON v.id = vt.visit_id WHERE vt.id = ?`
    )
    .get(req.params.id);
  if (!vt) return res.status(404).json({ error: 'Not found' });

  const { message } = req.body;
  if (!message?.trim()) return res.status(400).json({ error: 'Message required' });

  const id = uuid();
  db.prepare(
    'INSERT INTO task_questions (id, visit_task_id, author_id, message) VALUES (?, ?, ?, ?)'
  ).run(id, vt.id, req.user.id, message.trim());

  const author = db.prepare('SELECT display_name, role FROM users WHERE id = ?').get(req.user.id);

  if (author.role === 'cleaner') {
    void sendExpoPush(getHouseholdManagerPushTokens(vt.home_id, req.user.id), {
      title: 'Question on a task',
      body: `${author.display_name}: ${message.trim().slice(0, 80)}`,
      data: { type: 'task_question', visitTaskId: vt.id, questionId: id },
    });
  } else {
    const members = db
      .prepare(
        `SELECT u.push_token FROM users u
         JOIN home_members hm ON hm.user_id = u.id
         WHERE hm.home_id = ? AND u.id != ?`
      )
      .all(vt.home_id, req.user.id);
    void sendExpoPush(
      members.map((m) => m.push_token),
      {
        title: 'Owner replied',
        body: `${author.display_name}: ${message.trim().slice(0, 80)}`,
        data: { type: 'task_reply', visitTaskId: vt.id, questionId: id },
      }
    );
  }

  const question = db
    .prepare(
      `SELECT q.*, u.display_name as author_name, u.role as author_role
       FROM task_questions q JOIN users u ON u.id = q.author_id WHERE q.id = ?`
    )
    .get(id);
  res.json(question);
});

app.get('/notifications/unread-count', authRequired, (req, res) => {
  const home = getHomeForUser(req.user.id);
  if (!home) return res.json({ count: 0 });

  if (req.user.role === 'client') {
    const questions = db
      .prepare(
        `SELECT COUNT(*) as c FROM task_questions q
         JOIN visit_tasks vt ON vt.id = q.visit_task_id
         JOIN visits v ON v.id = vt.visit_id
         JOIN users u ON u.id = q.author_id
         WHERE v.home_id = ? AND u.role = 'cleaner'
         AND q.created_at > datetime('now', '-7 days')`
      )
      .get(home.id).c;
    const invoices = db
      .prepare(
        `SELECT COUNT(*) as c FROM invoices
         WHERE home_id = ? AND status = 'sent'`
      )
      .get(home.id).c;
    return res.json({ count: questions + invoices });
  }

  res.json({ count: 0 });
});

// ─── Payment methods (legacy — admin-only fallback; MVP uses Stripe Connect) ─

app.get('/payment-methods/mine', authRequired, (req, res) => {
  const row = db.prepare('SELECT * FROM payment_methods WHERE user_id = ?').get(req.user.id);
  res.json(
    row || {
      user_id: req.user.id,
      venmo_handle: null,
      zelle_contact: null,
      cashapp_handle: null,
      paypal_handle: null,
    }
  );
});

app.get('/payment-methods/cleaner/:cleanerId', authRequired, (req, res) => {
  const home = getHomeForUser(req.user.id);
  if (!home) return res.status(403).json({ error: 'No home' });

  const member = db
    .prepare(
      `SELECT 1 FROM home_members WHERE home_id = ? AND user_id = ? AND role = 'cleaner'`
    )
    .get(home.id, req.params.cleanerId);
  const isOwner = home.owner_id === req.user.id;
  if (!isOwner && !member && req.params.cleanerId !== req.user.id) {
    return res.status(403).json({ error: 'Not allowed' });
  }

  const row = db.prepare('SELECT * FROM payment_methods WHERE user_id = ?').get(req.params.cleanerId);
  const cleaner = db
    .prepare('SELECT id, display_name FROM users WHERE id = ?')
    .get(req.params.cleanerId);
  res.json({
    cleaner,
    methods: row || {
      venmo_handle: null,
      zelle_contact: null,
      cashapp_handle: null,
      paypal_handle: null,
    },
  });
});

app.put('/payment-methods/mine', authRequired, (req, res) => {
  // Deprecated for MVP checkout — Venmo/Zelle/Cash App/PayPal are not the primary pay flow.
  // Retained for admin-only manual reconciliation if needed post-MVP.
  if (req.user.role !== 'cleaner') {
    return res.status(403).json({ error: 'Only cleaners can set payment methods' });
  }
  const { venmoHandle, zelleContact, cashappHandle, paypalHandle } = req.body;
  const existing = db.prepare('SELECT user_id FROM payment_methods WHERE user_id = ?').get(req.user.id);
  if (existing) {
    db.prepare(
      `UPDATE payment_methods SET
        venmo_handle = ?, zelle_contact = ?, cashapp_handle = ?, paypal_handle = ?,
        updated_at = datetime('now')
       WHERE user_id = ?`
    ).run(
      venmoHandle?.trim() || null,
      zelleContact?.trim() || null,
      cashappHandle?.trim() || null,
      paypalHandle?.trim() || null,
      req.user.id
    );
  } else {
    db.prepare(
      `INSERT INTO payment_methods (user_id, venmo_handle, zelle_contact, cashapp_handle, paypal_handle)
       VALUES (?, ?, ?, ?, ?)`
    ).run(
      req.user.id,
      venmoHandle?.trim() || null,
      zelleContact?.trim() || null,
      cashappHandle?.trim() || null,
      paypalHandle?.trim() || null
    );
  }
  res.json(db.prepare('SELECT * FROM payment_methods WHERE user_id = ?').get(req.user.id));
});

// ─── Invoices (Stripe Connect primary; webhooks source of truth) ─────────────

function listInvoicesForUser(userId, role, home) {
  const rows =
    role === 'client'
      ? db
          .prepare(
            `SELECT i.*, u.display_name as cleaner_name, v.scheduled_date as visit_date
             FROM invoices i
             JOIN users u ON u.id = i.cleaner_id
             LEFT JOIN visits v ON v.id = i.visit_id
             WHERE i.home_id = ?
             ORDER BY i.created_at DESC LIMIT 50`
          )
          .all(home.id)
      : db
          .prepare(
            `SELECT i.*, u.display_name as cleaner_name, v.scheduled_date as visit_date
             FROM invoices i
             JOIN users u ON u.id = i.cleaner_id
             LEFT JOIN visits v ON v.id = i.visit_id
             WHERE i.cleaner_id = ?
             ORDER BY i.created_at DESC LIMIT 50`
          )
          .all(userId);
  return rows.map((row) => formatInvoiceRow(row));
}

app.get('/invoices', authRequired, (req, res) => {
  const home = getHomeForUser(req.user.id);
  if (!home) return res.json([]);
  res.json(listInvoicesForUser(req.user.id, req.user.role, home));
});

app.post('/invoices', authRequired, (req, res) => {
  if (req.user.role !== 'cleaner') {
    return res.status(403).json({ error: 'Only cleaners can send invoices' });
  }
  const home = getHomeForUser(req.user.id);
  if (!home) return res.status(403).json({ error: 'Join a home first' });

  const { amountCents, note, visitId } = req.body;
  if (!amountCents || amountCents < 100) {
    return res.status(400).json({ error: 'Amount must be at least $1.00' });
  }

  if (visitId) {
    const visit = db.prepare('SELECT * FROM visits WHERE id = ? AND home_id = ?').get(visitId, home.id);
    if (!visit) return res.status(404).json({ error: 'Visit not found' });
  }

  const connectStatus = getCleanerConnectStatus(req.user.id);
  if (!connectStatus.ready) {
    return res.status(400).json({
      error: 'Complete Stripe Connect onboarding before sending invoices',
      code: connectStatus.reason,
    });
  }

  const breakdown = buildInvoiceFeeBreakdown(amountCents, home.id, req.user.id);
  const id = uuid();
  db.prepare(
    `INSERT INTO invoices (
      id, home_id, visit_id, cleaner_id, agreement_id,
      amount_cents, cleaner_amount_cents, bradley_fee_cents, total_amount_cents,
      fee_type, fee_percent, note, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'sent')`
  ).run(
    id,
    home.id,
    visitId || null,
    req.user.id,
    breakdown.agreement_id,
    breakdown.cleaner_amount_cents,
    breakdown.cleaner_amount_cents,
    breakdown.bradley_fee_cents,
    breakdown.total_amount_cents,
    breakdown.fee_type,
    breakdown.fee_percent,
    note?.trim() || ''
  );

  const ownerId = getOwnerId(home.id);
  const owner = db.prepare('SELECT push_token FROM users WHERE id = ?').get(ownerId);
  const amount = (breakdown.total_amount_cents / 100).toFixed(2);
  const cleaner = db.prepare('SELECT display_name FROM users WHERE id = ?').get(req.user.id);
  void sendExpoPush([owner?.push_token], {
    title: 'New invoice',
    body: `${cleaner?.display_name || 'Your cleaner'} sent an invoice for $${amount}`,
    data: { type: 'invoice', invoiceId: id },
  });

  res.json(fetchInvoiceById(id));
});

app.get('/invoices/:id', authRequired, (req, res) => {
  const invoice = fetchInvoiceById(req.params.id);
  if (!invoice) return res.status(404).json({ error: 'Not found' });
  const home = getHomeForUser(req.user.id);
  if (!home || home.id !== invoice.home_id) {
    return res.status(403).json({ error: 'Not allowed' });
  }

  const payload = {
    invoice,
    stripeConfigured: isStripeConfigured(),
  };

  // Legacy off-platform handles — not exposed in MVP homeowner checkout UX.
  if (isAdminUser(req.user)) {
    const methods = db
      .prepare('SELECT * FROM payment_methods WHERE user_id = ?')
      .get(invoice.cleaner_id);
    payload.paymentMethods = methods || {};
    payload.paymentMethodsNote =
      'Admin-only fallback. MVP invoices must be paid through Stripe in-app.';
  }

  res.json(payload);
});

app.post('/invoices/:id/payment-intent', authRequired, async (req, res) => {
  const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(req.params.id);
  if (!invoice) return res.status(404).json({ error: 'Not found' });

  const home = getHomeForUser(req.user.id);
  if (!home || home.id !== invoice.home_id || !isHouseholdClient(req.user.id, home.id)) {
    return res.status(403).json({ error: 'Only the homeowner can pay invoices' });
  }

  const connectStatus = getCleanerConnectStatus(invoice.cleaner_id);
  if (!connectStatus.ready) {
    return res.status(400).json({
      error: 'Cleaner must complete Stripe Connect onboarding before receiving payment',
      code: connectStatus.reason,
    });
  }

  const result = await createPaymentIntentForInvoice(invoice.id, req.user.id);
  if (result.error) {
    return res.status(result.status || 400).json({ error: result.error });
  }

  const formatted = fetchInvoiceById(invoice.id);
  res.json({
    invoice: formatted,
    paymentIntent: {
      id: result.paymentIntent.id,
      stripe_payment_intent_id: result.paymentIntent.stripe_payment_intent_id,
      status: result.paymentIntent.status,
      cleaner_amount_cents: result.paymentIntent.cleaner_amount_cents,
      bradley_fee_cents: result.paymentIntent.bradley_fee_cents,
      total_amount_cents: result.paymentIntent.total_amount_cents,
      fee_type: result.paymentIntent.fee_type,
      fee_percent: result.paymentIntent.fee_percent,
      cleaner_payout_cents: result.paymentIntent.cleaner_amount_cents,
      cleaner_payout_display: `$${(result.paymentIntent.cleaner_amount_cents / 100).toFixed(2)}`,
      client_secret: result.clientSecret ?? null,
    },
    stripeConfigured: isStripeConfigured(),
    created: result.created,
  });
});

app.post('/invoices/:id/checkout-session', authRequired, async (req, res) => {
  const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(req.params.id);
  if (!invoice) return res.status(404).json({ error: 'Not found' });

  const home = getHomeForUser(req.user.id);
  if (!home || home.id !== invoice.home_id || !isHouseholdClient(req.user.id, home.id)) {
    return res.status(403).json({ error: 'Only the homeowner can pay invoices' });
  }

  const connectStatus = getCleanerConnectStatus(invoice.cleaner_id);
  if (!connectStatus.ready) {
    return res.status(400).json({
      error: 'Cleaner must complete Stripe Connect onboarding before receiving payment',
      code: connectStatus.reason,
    });
  }

  const { successUrl, cancelUrl } = req.body || {};
  const result = await createCheckoutSessionForInvoice(invoice.id, req.user.id, {
    successUrl,
    cancelUrl,
  });
  if (result.error) {
    return res.status(result.status || 400).json({ error: result.error });
  }

  res.json({
    url: result.url,
    sessionId: result.sessionId,
    invoice: fetchInvoiceById(invoice.id),
    stripeConfigured: isStripeConfigured(),
  });
});

app.patch('/invoices/:id/paid', authRequired, (req, res) => {
  const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(req.params.id);
  if (!invoice) return res.status(404).json({ error: 'Not found' });

  const home = getHomeForUser(req.user.id);
  if (!home || home.id !== invoice.home_id || !isHouseholdClient(req.user.id, home.id)) {
    return res.status(403).json({ error: 'Only the homeowner can mark invoices paid' });
  }

  const { paidVia } = req.body;

  if (!invoiceHasSucceededPayment(invoice.id)) {
    if (isAdminUser(req.user) && paidVia) {
      // Admin-only manual fallback when Stripe/webhooks are unavailable.
      const updated = markInvoicePaidFromPayment(invoice.id, { paidVia });
      return res.json(updated);
    }
    return res.status(402).json({
      error: 'Payment required before marking invoice paid',
      code: 'payment_required',
      message:
        'Complete in-app payment through Bradley. Off-platform Venmo/Cash App/Zelle/PayPal is not supported in MVP.',
    });
  }

  res.json(fetchInvoiceById(invoice.id));
});

app.patch('/invoices/:id/cancel', authRequired, (req, res) => {
  const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(req.params.id);
  if (!invoice) return res.status(404).json({ error: 'Not found' });
  if (invoice.cleaner_id !== req.user.id) {
    return res.status(403).json({ error: 'Not allowed' });
  }
  if (invoice.status !== 'sent') {
    return res.status(400).json({ error: 'Invoice cannot be cancelled' });
  }
  db.prepare(`UPDATE invoices SET status = 'cancelled' WHERE id = ?`).run(invoice.id);
  res.json(fetchInvoiceById(invoice.id));
});

// ─── Admin ──────────────────────────────────────────────────────────────────

function deleteUserByEmail(email) {
  const user = db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase());
  if (!user) return false;

  const ownedHomes = db.prepare('SELECT id FROM homes WHERE owner_id = ?').all(user.id);
  for (const home of ownedHomes) {
    db.prepare('DELETE FROM homes WHERE id = ?').run(home.id);
  }

  db.prepare('DELETE FROM home_members WHERE user_id = ?').run(user.id);
  db.prepare('DELETE FROM task_questions WHERE author_id = ?').run(user.id);
  db.prepare('DELETE FROM visit_feedback WHERE author_id = ?').run(user.id);
  db.prepare('DELETE FROM invoices WHERE cleaner_id = ?').run(user.id);
  db.prepare('DELETE FROM payment_methods WHERE user_id = ?').run(user.id);
  db.prepare('UPDATE invites SET used_by = NULL WHERE used_by = ?').run(user.id);
  db.prepare('DELETE FROM users WHERE id = ?').run(user.id);
  return true;
}

app.get('/admin/users', authRequired, requireAdmin, (_req, res) => {
  const users = db
    .prepare(
      `SELECT id, email, display_name, role, subscription_status, created_at
       FROM users ORDER BY created_at DESC`
    )
    .all();
  res.json({
    users: users.map((u) => ({
      id: u.id,
      email: u.email,
      displayName: u.display_name,
      role: u.role,
      subscriptionStatus: u.subscription_status,
      createdAt: u.created_at,
    })),
  });
});

app.delete('/admin/users/:email', authRequired, requireAdmin, (req, res) => {
  const email = decodeURIComponent(req.params.email || '').toLowerCase();
  if (!email) return res.status(400).json({ error: 'Email required' });
  if (email === req.user.email?.toLowerCase()) {
    return res.status(400).json({ error: 'Cannot delete your own account' });
  }
  const deleted = deleteUserByEmail(email);
  if (!deleted) return res.status(404).json({ error: 'User not found' });
  res.json({ ok: true });
});

app.get('/config/payments', (_req, res) => {
  const publishableKey = getStripePublishableKey(getSetting);
  res.json({
    stripe_publishable_key: publishableKey || null,
    stripe_configured: isStripeConfigured(),
    checkout_available: isStripeConfigured(),
  });
});

app.get('/admin/health', authRequired, requireAdmin, (_req, res) => {
  res.json({ ok: true, service: 'bradley-admin' });
});

function buildAdminSettingsResponse() {
  const rows = db.prepare('SELECT key, value, updated_at FROM app_settings ORDER BY key').all();
  const settings = {};
  for (const row of rows) {
    settings[row.key] = maskSettingValue(row.key, row.value);
  }
  const publishableFromEnv = process.env.STRIPE_PUBLISHABLE_KEY?.trim();
  if (publishableFromEnv && !settings.stripe_publishable_key) {
    settings.stripe_publishable_key = maskSettingValue(
      'stripe_publishable_key',
      publishableFromEnv
    );
  }
  const secretFromEnv = Boolean(process.env.STRIPE_SECRET_KEY?.trim());
  const webhookFromEnv = Boolean(process.env.STRIPE_WEBHOOK_SECRET?.trim());
  if (secretFromEnv && !settings.stripe_secret_key) {
    settings.stripe_secret_key = maskSettingValue(
      'stripe_secret_key',
      process.env.STRIPE_SECRET_KEY.trim()
    );
  }
  if (webhookFromEnv && !settings.stripe_webhook_secret) {
    settings.stripe_webhook_secret = maskSettingValue(
      'stripe_webhook_secret',
      process.env.STRIPE_WEBHOOK_SECRET.trim()
    );
  }
  return {
    settings,
    stripe: {
      secret_configured: isStripeConfigured(),
      webhook_configured: isStripeWebhookConfigured(),
      secret_from_env: secretFromEnv,
      webhook_from_env: webhookFromEnv,
      publishable_key: maskSettingValue(
        'stripe_publishable_key',
        getStripePublishableKey(getSetting)
      ),
    },
  };
}

app.get('/admin/dashboard', authRequired, requireAdmin, (_req, res) => {
  const userCounts = db
    .prepare(
      `SELECT
         COUNT(*) AS total,
         SUM(CASE WHEN role = 'client' THEN 1 ELSE 0 END) AS homeowners,
         SUM(CASE WHEN role = 'cleaner' THEN 1 ELSE 0 END) AS cleaners,
         SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) AS admins
       FROM users`
    )
    .get();
  const revenueRow = db
    .prepare(
      `SELECT
         COALESCE(SUM(COALESCE(total_amount_cents, amount_cents)), 0) AS total_revenue_cents,
         COUNT(*) AS paid_invoices_count
       FROM invoices
       WHERE status = 'paid'`
    )
    .get();
  const platformFeesRow = db
    .prepare('SELECT COALESCE(SUM(fee_amount_cents), 0) AS platform_fees_cents FROM platform_fees')
    .get();
  const activeHomes = db.prepare('SELECT COUNT(*) AS c FROM homes').get()?.c ?? 0;
  const openCleaningRequests =
    db
      .prepare(
        `SELECT COUNT(*) AS c FROM cleaning_requests
         WHERE status IN ('open', 'proposals_received', 'draft')`
      )
      .get()?.c ?? 0;

  res.json({
    users: {
      total: userCounts?.total ?? 0,
      homeowners: userCounts?.homeowners ?? 0,
      cleaners: userCounts?.cleaners ?? 0,
      admins: userCounts?.admins ?? 0,
    },
    revenue: {
      total_cents: revenueRow?.total_revenue_cents ?? 0,
      platform_fees_cents: platformFeesRow?.platform_fees_cents ?? 0,
      paid_invoices_count: revenueRow?.paid_invoices_count ?? 0,
    },
    stripe_configured: isStripeConfigured(),
    stripe_webhook_configured: isStripeWebhookConfigured(),
    openai_configured: Boolean(getOpenAiApiKey(getSetting)),
    active_homes: activeHomes,
    open_cleaning_requests: openCleaningRequests,
  });
});

app.get('/admin/settings', authRequired, requireAdmin, (_req, res) => {
  res.json(buildAdminSettingsResponse());
});

app.put('/admin/settings', authRequired, requireAdmin, (req, res) => {
  const body = req.body || {};
  if (typeof body !== 'object' || Array.isArray(body)) {
    return res.status(400).json({ error: 'Invalid settings body' });
  }
  for (const [key, value] of Object.entries(body)) {
    if (!key || typeof key !== 'string') continue;
    if (typeof value !== 'string') continue;
    if (ENV_ONLY_SETTING_KEYS.has(key)) continue;
    if (value.startsWith('***') && SENSITIVE_SETTING_KEYS.has(key)) continue;
    setSetting(key, value);
  }
  resetStripeClient();
  res.json(buildAdminSettingsResponse());
});

registerCleanerProfileRoutes(app, { auth, authRequired, requireAdmin });
registerMarketplaceRoutes(app, { auth, authRequired, requireAdmin });

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'bradley-api' });
});

function getLanIp() {
  const nets = networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === 'IPv4' && !net.internal) {
        return net.address;
      }
    }
  }
  return '127.0.0.1';
}

app.listen(PORT, '0.0.0.0', () => {
  const ip = getLanIp();
  console.log(`Bradley API running on http://${ip}:${PORT}`);
  console.log(`Local: http://127.0.0.1:${PORT}`);
});
